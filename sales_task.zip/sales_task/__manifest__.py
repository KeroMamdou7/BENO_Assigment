{
    'name': 'Sales Flow',
    "summary":"Sales_Flow",
    "depends":['base','sale','sale_management'],
    "data":[
        "security/ir.model.access.csv",
        "views/menu_template.xml"
    ],
}
