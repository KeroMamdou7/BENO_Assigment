from odoo import api, fields,models

class SalesEvent(models.Model):
    _name="sale.event"

    def action_is_lead(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Existing Lead',
            'view_mode': 'kanban',
            'res_model': 'res.partner',  # Replace with the actual model name
            'view_id': self.env.ref('base.res_partner_kanban_view').id,
            'target': 'current',
        }

    def action_not_lead(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Individual Or Company',
            'view_mode': 'form',
            'res_model': 'new.customer',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.new_customer_form').id,
            'target': 'new',
        }
    