from odoo import api, fields,models

class DirectLead(models.Model):
    _name="direct.lead"