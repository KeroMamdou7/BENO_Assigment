from odoo import api, fields,models

class Sales(models.Model):
    _name="sale.button"

    def action_event_sale(self):
        # Replace 'your_module.view_1_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Event Sale',
            'view_mode': 'tree',
            'res_model': 'sale.order',  # Replace with the actual model name
            'view_id': self.env.ref('sale.view_order_tree').id,
            'target': 'current',
        }

    def action_direct_sale(self):
        # Replace 'your_module.view_2_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Direc Sale',
            'view_mode': 'form',
            'res_model': 'sale.direct',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.sale_direct_form').id,
            'target': 'new',
        }