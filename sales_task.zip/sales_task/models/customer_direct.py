from odoo import api, fields,models

class DirectCustomer(models.Model):
    _name="direct.customer"

    def action_new_customer(self):
        # Replace 'your_module.view_1_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Individual Or Company',
            'view_mode': 'form',
            'res_model': 'new.customer',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.new_customer_form').id,
            'target': 'new',
        }

    def action_not_new_customer(self):
        # Replace 'your_module.view_2_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Customers',
            'view_mode': 'kanban',
            'res_model': 'res.partner',  # Replace with the actual model name
            'view_id': self.env.ref('base.res_partner_kanban_view').id,
            'target': 'current',
        }