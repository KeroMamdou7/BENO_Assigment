from odoo import api, fields,models

class IsLead(models.Model):
    _name="is.lead"

    def action_is_lead(self):
        # Replace 'your_module.view_1_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Existing Lead',
            'view_mode': 'kanban',
            'res_model': 'res.partner',  # Replace with the actual model name
            'view_id': self.env.ref('base.res_partner_kanban_view').id,
            'target': 'current',
        }

    def action_not_lead(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Individual Or Company',
            'view_mode': 'form',
            'res_model': 'new.customer',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.new_customer_form').id,
            'target': 'new',
        }
    