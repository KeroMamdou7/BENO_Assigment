from odoo import api, fields,models

class SalesDirect(models.Model):
    _name="sale.direct"
    

    def action_direct_lead(self):
        # Replace 'your_module.view_1_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Direct Lead',
            'view_mode': 'form',
            'res_model': 'sale.event',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.sale_event_form').id,
            'target': 'new',
        }

    def action_direct_customer(self):
        # Replace 'your_module.view_2_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Direct Customer',
            'view_mode': 'form',
            'res_model': 'direct.customer',  # Replace with the actual model name
            'view_id': self.env.ref('sales_task.direct_customer_form').id,
            'target': 'new',
        }