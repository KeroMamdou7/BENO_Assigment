from odoo import api, fields,models

class NewCustomer(models.Model):
    _name="new.customer"

    def action_individual_customer(self):
        # Replace 'your_module.view_1_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Individual',
            'view_mode': 'form',
            'res_model': 'res.partner',  # Replace with the actual model name
            'view_id': self.env.ref('base.view_partner_form').id,
            'target': 'current',
        }

    def action_company_customer(self):
        # Replace 'your_module.view_2_form' with the actual XML ID of the view you want to navigate to
        return {
            'type': 'ir.actions.act_window',
            'name': 'Customers',
            'view_mode': 'form',
            'res_model': 'res.partner',  # Replace with the actual model name
            'view_id': self.env.ref('base.view_partner_form').id,
            'target': 'current',
        }